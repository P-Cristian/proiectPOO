import java.lang.reflect.Array;
import java.time.LocalDate;
import java.util.ArrayList;

public class SlujbaService extends Service {
	public SlujbaService(Repository<Slujba> repo)
	{
		super(repo);

	}
	public void setAvailableId(Slujba object) {
		ArrayList<Slujba> slujbaList = super.getList();
		int maxId = 0;
		for (int i=0;i<slujbaList.size();i++) {
			maxId = Math.max(maxId, slujbaList.get(i).getId());
		}
		int[] existingIds = new int[maxId + 1];
		for (int i=0;i<slujbaList.size();i++) {
			existingIds[slujbaList.get(i).getId() - 1] = 1;
		}
		for (int i = 0; i <= maxId; i++) {
			if (existingIds[i] == 0) {
				object.setId(i + 1);
				break;
			}
		}
	}
	public void add(Slujba a) {
		super.repo.add(a);
	}
	public String addSlujba(String numeSlujba, String anSlujba, String lunaSlujba , String ziSlujba)
	{
		String checkError = super.checkNumar(anSlujba,4000);
		if (checkError!="valid!") return checkError;
		checkError = super.checkNume(numeSlujba,25);
		if (checkError!="valid!") return checkError;
		checkError = super.checkNumar(lunaSlujba,13 );
		if (checkError!="valid!") return checkError;
		checkError = super.checkNumar(ziSlujba,32 );
		if (checkError!="valid!") return checkError;
		checkError = super.checkData(anSlujba, lunaSlujba, ziSlujba);
		if (checkError!="valid!") return checkError;
		Slujba a = new Slujba(numeSlujba,Integer.parseInt(anSlujba),Integer.parseInt(lunaSlujba),Integer.parseInt(ziSlujba));
		this.add(a);
		setAvailableId(a);
		return "valid!";

	}
	public ArrayList<String[]> getAllForPrint() {
		ArrayList<Slujba> listaPrint = super.getList();
		ArrayList<String[]> result = new ArrayList<String[]>();
		for(int i=0;i<listaPrint.size();i++)
		{
			String[] object  = new String[5];
			object[0] =  String.valueOf(listaPrint.get(i).getId());
			object[1] = listaPrint.get(i).getNume();
			LocalDate printedDate = listaPrint.get(i).getData_Ora();
			object[2] = String.valueOf(printedDate.getYear());
			object[3] = String.valueOf(printedDate.getMonthValue());
			object[4] = String.valueOf(printedDate.getDayOfMonth());
			result.add(object);
		}
		return result;
	}
	public String removeSlujba(String id) {
		String checkError = super.checkNumar(id,5000);

		if(checkError=="valid!")
		{
			int pos = this.existId(Integer.parseInt(id));
			if(pos!=-1)
			{
				super.remove(pos);
				return "valid!";
			}
			return checkError;
		}
		return checkError;

	}

	public int existId(int id) {
		try {

			ArrayList<Slujba> lista = this.repo.getList();
			for (int i = 0; i < this.repo.size(); i++) {
				if (id == lista.get(i).getId()) {
					return i;
				}
			}
			throw new IllegalArgumentException("Id does not exist");
		} catch (IllegalArgumentException ex) {
			return -1;
		}
	}

	public String updateSlujba(String id, String newTitle, String newAn, String newLuna,String newZi){

		String checkError = super.checkNumar(id,5000);
		if(checkError!="valid!") return checkError;
		if(checkError=="valid!")
		{
			int pos = this.existId(Integer.parseInt(id));
			if(pos!=-1)
			{
				checkError = this.checkUpdate(id, newTitle, newAn, newLuna,newZi,pos);
				return checkError;
			}
			return checkError;
		}
		return checkError;
	}

	public String checkUpdate(String id, String newTitle, String newYear , String newMonth, String newDay, int pos)
	{
		String checkError = super.checkNumar(id,5000);
		if (checkError!="valid!") return checkError;
		checkError = super.checkNume(newTitle,25);
		if (checkError!="valid!") return checkError;
		checkError = super.checkNumar(newYear, 4000);
		if (checkError!="valid!") return checkError;
		checkError = super.checkNumar(newMonth, 13);
		if (checkError!="valid!") return checkError;
		checkError = super.checkNumar(newDay, 32);
		if (checkError!="valid!") return checkError;

		return executeUpdate(id, newTitle, newYear, newMonth, newDay, pos) ;
	}
	public String executeUpdate(String id , String newTitle, String newYear, String newMonth, String newDay, int pos)
	{
		Slujba a = new Slujba(newTitle,Integer.parseInt(newYear),Integer.parseInt(newMonth),Integer.parseInt(newDay));
		a.setId(Integer.parseInt(id));
		super.update(a, pos);
		return "valid!";
	}

	public String getStringSlujbeByMonth(int yearValue, int monthValue, int dayValue) {
		ArrayList<Slujba> lista = super.getList();
		String result= new String();
		for(int i=0;i<lista.size();i++)
		{
			if(lista.get(i).getData_Ora().getYear()==yearValue && lista.get(i).getData_Ora().getMonthValue()==monthValue && lista.get(i).getData_Ora().getDayOfMonth()==dayValue)
			{
				result= result+" "+ lista.get(i).getNume() + "|";
			}
		}
		return result;
	}
}
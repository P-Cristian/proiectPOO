import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainMenu extends MainFrame implements ActionListener {

    Console console;
    JPanel buttonPanel = new JPanel();
    JButton serviciiButton,prediciAnunturiButton,sfintiiButton,ajutorButton,slujbaButton,enoriasButton;

    MainMenu(Console console){

        this.console = console;
        mainMenu();
    }

    public JPanel getButtonPanel(){
        return  buttonPanel;
    }
    private void mainMenu()
    {
        buttonPanel.setLayout(new GridLayout(7,1,10,30));
        buttonPanel.setSize(new Dimension(100,50));

        serviciiButton = new JButton("Servicii Religioase");
        prediciAnunturiButton = new JButton("Predici/Anunțuri");
        slujbaButton = new JButton("Slujbe");
        sfintiiButton = new JButton("Sfinții pomeniți azi și/sau sărbătorile!");
        ajutorButton = new JButton("Ajutor");
        enoriasButton = new JButton("Enoriasi");
        serviciiButton.addActionListener(this);
        prediciAnunturiButton.addActionListener(this);
        slujbaButton.addActionListener(this);
        sfintiiButton.addActionListener(this);
        ajutorButton.addActionListener(this);
        enoriasButton.addActionListener(this);

        buttonPanel.add(enoriasButton);
        buttonPanel.add(serviciiButton);
        buttonPanel.add(prediciAnunturiButton);
        buttonPanel.add(slujbaButton);
        buttonPanel.add(sfintiiButton);
        buttonPanel.add(ajutorButton);

    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if(e.getSource() == serviciiButton)
        {
            ServiciiDialogBox sdb = new ServiciiDialogBox(this.console);

        } else if (e.getSource() == prediciAnunturiButton)
        {
            PrediciAnunturiDBox padb = new PrediciAnunturiDBox(this.console);

        } else if (e.getSource() == slujbaButton)
        {
            SlujbeDialogBox sljdb = new SlujbeDialogBox(this.console);

        } else if (e.getSource() == enoriasButton)
        {
            EnoriasiDialogBox edb = new EnoriasiDialogBox(this.console);
        }



    }
}

import java.time.LocalDate;


public class Serviciu {

    private int id;
    private String nume;
    private LocalDate dataOra;
    private Enorias enorias;

    public Serviciu(){
        id = 1;
        nume = "";
        dataOra = LocalDate.now();
        enorias = null;
    }
    public Serviciu( LocalDate dataOra)
    {
        id = 1;
        nume="";
        this.dataOra  = dataOra;
        enorias = null;
    }

    public Serviciu(String nume,Enorias enorias,int an, int luna, int zii)
    {
        id =1;
        this.nume = nume;
        this.dataOra=LocalDate.of(an, luna, zii);
        this.enorias = enorias;
    }

    public int getId()
    {
        return id;
    }
    public void setId(int newId)
    {
        this.id = newId;
    }
    public LocalDate getDataOra()
    {
        return dataOra;
    }

    public Enorias getEnorias()
    {
        return enorias;
    }
    public String getNume()
    {
        return nume;
    }
    public void setNume(String newNume)
    {
        this.nume=newNume;
    }
    public void setDataOra(LocalDate dataOra)
    {
        this.dataOra = dataOra;
    }

}
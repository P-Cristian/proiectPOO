
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Scanner;

public class FileRepo {
    private AnuntService anuntService;
    private SlujbaService slujbaService;
    private EnoriasService enoriasService;
    private ServiciuService serviciuService;

    public FileRepo(AnuntService anuntService, SlujbaService slujbaService, EnoriasService enoriasService, ServiciuService serviciuService) {
        this.anuntService = anuntService;
        this.enoriasService = enoriasService;
        this.serviciuService = serviciuService;
        this.slujbaService = slujbaService;
    }

    public void readAnunt(String fileName) throws FileNotFoundException {

        try {
            Scanner scanner = new Scanner(new File(fileName));
            while (scanner.hasNext()) {

                int id = Integer.parseInt(scanner.nextLine());
                String titlu = scanner.nextLine();
                String continut = scanner.nextLine();
                boolean isAnunt = Boolean.parseBoolean(scanner.nextLine());
                Anunt a = new Anunt(titlu, continut, isAnunt);
                a.setId(id);
                this.anuntService.add(a);
            }
        } catch (FileNotFoundException e) {
            throw new FileNotFoundException();
        }


    }

    public void readSlujba(String fileName) throws FileNotFoundException {

        try {
            Scanner scanner = new Scanner(new File(fileName));
            while (scanner.hasNext()) {

                int id = Integer.parseInt(scanner.nextLine());
                String nume = scanner.nextLine();
                int an = Integer.parseInt(scanner.nextLine());
                int luna = Integer.parseInt(scanner.nextLine());
                int zi = Integer.parseInt(scanner.nextLine());
                Slujba a = new Slujba(nume, an, luna, zi);
                a.setId(id);
                this.slujbaService.add(a);
            }
        } catch (FileNotFoundException e) {
            throw new FileNotFoundException();
        }


    }

    public void readEnorias(String fileName) throws FileNotFoundException {

        try {
            Scanner scanner = new Scanner(new File(fileName));
            while (scanner.hasNext()) {

                int id = Integer.parseInt(scanner.nextLine());
                String nume = scanner.nextLine();
                String telefon = scanner.nextLine();
                String adresa = scanner.nextLine();
                Enorias a = new Enorias(nume, telefon, adresa);
                a.setId(id);
                this.enoriasService.add(a);
            }
        } catch (FileNotFoundException e) {
            throw new FileNotFoundException();
        }


    }

    public void readServiciu(String fileName) throws FileNotFoundException {

        try {
            Scanner scanner = new Scanner(new File(fileName));
            while (scanner.hasNext()) {

                int id = Integer.parseInt(scanner.nextLine());
                String nume = scanner.nextLine();
                int idEnorias = Integer.parseInt(scanner.nextLine());
                int an = Integer.parseInt(scanner.nextLine());
                int luna = Integer.parseInt(scanner.nextLine());
                int zi = Integer.parseInt(scanner.nextLine());
                Enorias a = this.enoriasService.getEnoriasById(String.valueOf(idEnorias));
                Serviciu b = new Serviciu(nume, a, an, luna, zi);
                b.setId(id);
                this.serviciuService.add(b);
            }
        } catch (FileNotFoundException e) {
            throw new FileNotFoundException();
        }


    }

    public void writeAnunt(String fileName) throws IOException {

        try {
            new PrintWriter(fileName).close();
            File file = new File(fileName);
            FileOutputStream stream = new FileOutputStream(file);
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(stream));
            ArrayList<Anunt> list = this.anuntService.getList();
            for (int i = 0; i < list.size(); i++) {
                Anunt a = list.get(i);
                writer.write(String.valueOf(a.getId()));
                writer.newLine();
                writer.write(a.getTitlu());
                writer.newLine();
                writer.write(a.getContinut());
                writer.newLine();
                writer.write(String.valueOf(a.getEsteAnunt()));
                writer.newLine();
            }
            writer.close();
        } catch (FileNotFoundException e) {
            throw new FileNotFoundException();
        }

    }

    public void writeSlujba(String fileName) throws IOException {

        try {
            new PrintWriter(fileName).close();
            File file = new File(fileName);
            FileOutputStream stream = new FileOutputStream(file);
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(stream));
            ArrayList<Slujba> list = this.slujbaService.getList();
            for (int i = 0; i < list.size(); i++) {
                Slujba a = list.get(i);
                writer.write(String.valueOf(a.getId()));
                writer.newLine();
                writer.write(a.getNume());
                writer.newLine();
                writer.write(String.valueOf(a.getData_Ora().getYear()));
                writer.newLine();
                writer.write(String.valueOf(a.getData_Ora().getMonthValue()));
                writer.newLine();
                writer.write(String.valueOf(a.getData_Ora().getDayOfMonth()));
                writer.newLine();
            }
            writer.close();
        } catch (FileNotFoundException e) {
            throw new FileNotFoundException();
        }

    }

    public void writeEnorias(String fileName) throws IOException {

        try {
            new PrintWriter(fileName).close();
            File file = new File(fileName);
            FileOutputStream stream = new FileOutputStream(file);
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(stream));
            ArrayList<Enorias> list = this.enoriasService.getList();
            for (int i = 0; i < list.size(); i++) {
                Enorias a = list.get(i);
                writer.write(String.valueOf(a.getId()));
                writer.newLine();
                writer.write(a.getNume());
                writer.newLine();
                writer.write(a.getTelefon());
                writer.newLine();
                writer.write(a.getAdresa());
                writer.newLine();
            }
            writer.close();
        } catch (FileNotFoundException e) {
            throw new FileNotFoundException();
        }

    }

    public void writeServiciu(String fileName) throws IOException {

        try {
            new PrintWriter(fileName).close();
            File file = new File(fileName);
            FileOutputStream stream = new FileOutputStream(file);
            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(stream));
            ArrayList<Serviciu> list = this.serviciuService.getList();
            for (int i = 0; i < list.size(); i++) {
                Serviciu a = list.get(i);
                writer.write(String.valueOf(a.getId()));
                writer.newLine();
                writer.write(a.getNume());
                writer.newLine();
                writer.write(String.valueOf(a.getEnorias().getId()));
                writer.newLine();
                writer.write(String.valueOf(a.getDataOra().getYear()));
                writer.newLine();
                writer.write(String.valueOf(a.getDataOra().getMonthValue()));
                writer.newLine();
                writer.write(String.valueOf(a.getDataOra().getDayOfMonth()));
                writer.newLine();
            }
            writer.close();
        } catch (FileNotFoundException e) {
            throw new FileNotFoundException();
        }

    }
}
	
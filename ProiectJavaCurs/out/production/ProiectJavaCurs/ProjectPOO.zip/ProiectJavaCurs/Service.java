import java.util.ArrayList;
import java.time.LocalDate;
public abstract class Service<T> {
		protected Repository<T> repo;
		protected String error;
		public Service(Repository<T> repo)
		{
			this.repo = repo;
		}
		public  void add(T a) {
			repo.add(a);
		}
		public ArrayList<T> getList()
		{
			return this.repo.getList();
		}
		public String checkNume(String titlu, int limit) {
		    try {
		        if (titlu.isEmpty()) {
		            throw new IllegalArgumentException("Input must not be empty");
		        }
		        if (Character.isDigit(titlu.charAt(0))) {
		            throw new IllegalArgumentException("First character must be a letter");
		        }
		        if (!Character.isUpperCase(titlu.charAt(0))) {
		            throw new IllegalArgumentException("First letter must be uppercase");
		        }
		        if (titlu.length() > limit) {
		            throw new IllegalArgumentException("Input must be less than " + (limit + 1) + " characters");
		        }
		        return "valid!";
		    } catch (IllegalArgumentException ex) {
		        return ex.getMessage();
		    }
		}

		private String isStringEmptyError(String titlu) {
		    try {
		        if (titlu.isEmpty()) {
		            throw new IllegalArgumentException("Input must not be empty");
		        }
		        return "valid!";
		    } catch (IllegalArgumentException ex) {
		        return ex.getMessage();
		    }
		}
		public String checkNumarBoolean(String isAnunt) {
		    try {
		        if (!isAnunt.equals("1") && !isAnunt.equals("2")) {
		            throw new IllegalArgumentException("Value should be 1 or 2");
		        }
		        return "valid!";
		    } catch (IllegalArgumentException ex) {
		        return ex.getMessage();
		    }
		}

		public String checkNumar(String id,int limit) {
			String error = new String();
			error= this.isStringEmptyError(id);
			if(error!="valid!") return error;
			error = this.isStringNumber(id);
			if(error!="valid!") return error;
			return error;
		}
		public String checkNumarLimit(String id, int limit) {
		    try {
		        int parsedId = Integer.parseInt(id);
		        if (parsedId > 0 && parsedId < limit) {
		            return "valid!";
		        } else {
		            return "value must be below " + String.valueOf(limit);
		        }
		    } catch (NumberFormatException e) {
		        return "value must be below " + String.valueOf(limit);
		    }
		}


		public  String isStringNumber(String id) {
		    try {
		        Integer.parseInt(id);
		        return "valid!";
		    } catch (NumberFormatException e) {
		        return "Input must be integer";
		    }
		}

     	public  String checkNumarTelefon(String numarTelefon) {
		try {
			if (numarTelefon.length() == 10 && numarTelefon.startsWith("07")) {
				for (int i = 0; i < 10; i++) {
					if (!Character.isDigit(numarTelefon.charAt(i))) {
						return "invalid";
					}
				}
				return "valid!";
			} else {
				return "invalid";
			}
		} catch (Exception e) {
			return "invalid";
		}
     	}


	public void remove(int index)
		{
			repo.remove(index);
		}
		public void update(T a , int index)
		{
			repo.update(a, index);
		}
		public String checkData(String anSlujba, String lunaSlujba, String ziSlujba) {
			try
			{
				LocalDate data = LocalDate.of(Integer.parseInt(anSlujba),Integer.parseInt(lunaSlujba),Integer.parseInt(ziSlujba));
				return "valid!";
			}
			catch (Exception e) {
		        return "Date does not exist";
		    }
		}

}

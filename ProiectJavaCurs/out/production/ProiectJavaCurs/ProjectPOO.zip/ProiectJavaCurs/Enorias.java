public class Enorias {

    private int id;
    private String nume,telefon,adresa;

    public Enorias(){


        id = 1;
        nume = "unknown";
        telefon = "unknown";
        adresa = "unknown";

    }

    public Enorias(String nume)
    {
        id = 1;
        this.nume = nume;
        telefon = "unknown";
        adresa = "unknown";

    }

    public Enorias(String nume, String telefon)
    {
        id = 1;
        this.nume = nume;
        this.telefon = telefon;
        adresa = "unknown";
    }

    public Enorias(String nume, String telefon, String adresa)
    {
        id = 1;
        this.nume = nume;
        this.telefon = telefon;
        this.adresa = adresa;
    }



    public int getId()
    {
        return id;
    }

    public String getNume()
    {
        return nume;
    }

    public String getTelefon()
    {
        return telefon;
    }

    public String getAdresa()
    {
        return adresa;
    }

    public void setNume( String nume)
    {
        this.nume = nume;
    }

    public void setTelefon(String telefon)
    {
        this.telefon = telefon;
    }

    public void setAdresa(String adresa)
    {
        this.adresa = adresa;
    }

    public void setId(int id2) {
        this.id=id2;

    }
}
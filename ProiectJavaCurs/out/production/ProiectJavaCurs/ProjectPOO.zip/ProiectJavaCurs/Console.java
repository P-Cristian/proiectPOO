import javax.print.PrintService;
import javax.print.PrintServiceLookup;
import java.awt.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Scanner;
import java.awt.print.*;
public class Console {
	private AnuntService anuntService;
	private SlujbaService slujbaService;
	private EnoriasService enoriasService;
	private ServiciuService serviciuService;
	private int Input = 1;

	public Console(AnuntService anuntService, SlujbaService slujbaService, EnoriasService enoriasService,ServiciuService serviciuService) {
		this.anuntService = anuntService;
		this.slujbaService = slujbaService;
		this.enoriasService = enoriasService;
	    this.serviciuService = serviciuService;
	}

	private String printSlujbeServicii() {
		LocalDate currentDate = LocalDate.now();
		ArrayList<String> result = new ArrayList<String>();
		result.add(slujbaService.getStringSlujbeByMonth(currentDate.getYear(),currentDate.getMonthValue(),currentDate.getDayOfMonth()));
		result.add(serviciuService.getServiciiByMonth(currentDate.getYear(),currentDate.getMonthValue(),currentDate.getDayOfMonth()));
		if(result.isEmpty()) return "no such serviciu/sluja exist";
		printStrings(result);
		return "serviciu/slujba are being printed";
	}
	public String getSfintiZiuaCurenta() {
		LocalDate currentDate = LocalDate.now();
		int month = currentDate.getMonthValue();
		switch (month) {
			case 1:
				return getSfintiFromFile("Ianuarie.txt", currentDate.getDayOfMonth());
			case 2:
				return getSfintiFromFile("Februarie.txt", currentDate.getDayOfMonth());

			case 3:
				return getSfintiFromFile("Martie.txt", currentDate.getDayOfMonth());
			case 4:
				return getSfintiFromFile("Aprilie.txt", currentDate.getDayOfMonth());
			case 5:
				return getSfintiFromFile("Mai.txt", currentDate.getDayOfMonth());
			case 6:
				return getSfintiFromFile("Iunie.txt", currentDate.getDayOfMonth());
			case 7:
				return getSfintiFromFile("Iulie.txt", currentDate.getDayOfMonth());
			default:
				return "Luna indisponibila momentan";
		}
	}




	public String getSfintiFromFile(String filename, int day)
	{
		
	}
	public void printStrings(ArrayList<String> lines) {
		PrintService printService = PrintServiceLookup.lookupDefaultPrintService();
		if (printService != null) {
			Printable printable = new Printable() {
				public int print(Graphics graphics, PageFormat pageFormat, int pageIndex) {
					if (pageIndex > 0) {
						return NO_SUCH_PAGE;
					}
					int y = 100;
					for (String line : lines) {
						graphics.drawString(line, 100, y);
						y += 20;
					}
					return PAGE_EXISTS;
				}
			};
			PrinterJob job = PrinterJob.getPrinterJob();
			job.setPrintable(printable);
			try {
				job.print();
			} catch (PrinterException e) {
				e.printStackTrace();
			}
		} else {
			System.err.println("No printer found.");
		}
	}
	public String getDataNewAnunt(String unu, String doi, String trei) {
		String error = new String();
		error = this.anuntService.addAnunt(unu, doi, trei);
		return error;
	}

	public String getDataNewSlujba(String titlu, String an, String luna, String zi) {
		String error = new String();
		error = this.slujbaService.addSlujba(titlu,an,luna,zi);
		return error;
	}

	public String getDataNewEnorias(String nume, String telefon, String adresa) {
		String error = new String();
		error = this.enoriasService.addEnorias(nume,telefon,adresa);
		return error;
	}

	public String getDataNewServiciu(String idEnorias, String nume, String an, String luna, String zi) {
		String error = new String();
		error = this.serviciuService.addServiciu(nume,this.enoriasService.getEnoriasById(idEnorias) , an, luna, zi);
		return error;
	}

	public ArrayList<String[]> displayServicii() {
		ArrayList<String[]> displayResult = new ArrayList<String[]>();
		displayResult = this.serviciuService.getAllForPrint();
		return displayResult;
	}

	private void getDataNewSlujba() {
		ArrayList<String> dataSlujba = new ArrayList<String>();
		dataSlujba = this.newSlujbaInfo();
		String error = new String();
		error = this.slujbaService.addSlujba(dataSlujba.get(0), dataSlujba.get(1), dataSlujba.get(2), dataSlujba.get(3));
	}

	private ArrayList<String> newSlujbaInfo() {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter slujba nume");
		String slujbaNume = sc.nextLine();

		System.out.println("Enter slujba an");
		String slujbaAn = sc.nextLine();

		System.out.println("Enter slujba luna(numar)");
		String slujbaLuna = sc.nextLine();

		System.out.println("Enter slujba zii");
		String slujbaZii = sc.nextLine();

		ArrayList<String> resultAnuntData = this.formArraySlujba(slujbaNume, slujbaAn, slujbaLuna, slujbaZii);

		return resultAnuntData;
	}

	private ArrayList<String> formArraySlujba(String slujbaNume, String slujbaAn, String slujbaLuna, String slujbaZii) {
		ArrayList<String> result = new ArrayList<String>();
		result.add(slujbaNume);
		result.add(slujbaAn);
		result.add(slujbaLuna);
		result.add(slujbaZii);
		return result;
	}

	public ArrayList<String[]> displayAnunturi() {
		ArrayList<String[]> displayResult = new ArrayList<String[]>();
		displayResult = anuntService.getAllForPrint();
		return displayResult;
	}

	public ArrayList<String[]> displaySlujbe() {
		ArrayList<String[]> displayResult = new ArrayList<String[]>();
		displayResult = slujbaService.getAllForPrint();
		return displayResult;
	}

	public ArrayList<String[]> displayEnoriasi() {
		ArrayList<String[]> displayResult = new ArrayList<String[]>();
		displayResult = enoriasService.getAllForPrint();
		return displayResult;
	}

	private String getId(String objectName, String actionName) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter id of " + objectName + " you want to " + actionName);
		String searchedId = sc.nextLine();
		return searchedId;

	}

	private void callRemoveFunction(String objectName, String id) {
		String error = new String();
		if (objectName == "Anunt") error = this.anuntService.removeAnunt(id);
		else error = this.slujbaService.removeSlujba(id);
		this.displayItemChange(error, id, objectName, "removed");

	}

	private void displayItemChange(String error, String id, String itemName, String action) {
		if (error == "valid!") {
			System.out.println(itemName + " of index " + id + " was " + action + " succesfuly ");
		}

	}

	public String callUpdateAnunt(String id, String titlu, String continut, String isAnunt) {
		String error = new String();
		error = this.anuntService.updateAnunt(id, titlu, continut, isAnunt);
		return error;
	}

	public String callUpdateSlujba(String id, String titlu, String an, String luna,String zi) {
		String error = new String();
		error = this.slujbaService.updateSlujba(id, titlu, an, luna, zi);
		return error;
	}

	public String callUpdateEnorias(String id, String nume, String telefon, String adresa) {
		String error = new String();
		error = this.enoriasService.updateEnorias(id,nume,telefon,adresa);
		return error;
	}

	public String callUpdateServiciu(String id, String idEnorias, String nume, String an,String luna,String zi) {
		String error = new String();
		if(this.enoriasService.getEnoriasById(idEnorias)!=null)
		{
			error = this.serviciuService.updateServiciu(id,this.enoriasService.getEnoriasById(idEnorias),nume,an,luna,zi);
		}
		else
		{
			return "id of Enorias does not exist";
		}
		return error;
	}
	public String removeAnunt(String id) {
		String error = new String();
		error = this.anuntService.removeAnunt(id);
		return error;
	}

	public String removeSlujba(String id) {
		String error = new String();
		error = this.slujbaService.removeSlujba(id);
		return error;
	}

	public String removeEnorias(String id) {
		String error = new String();
		error = this.enoriasService.removeEnorias(id);
		return error;
	}

	public String removeServiciu(String id) {
		String error = new String();
		error = this.serviciuService.removeServiciu(id);
		return error;
	}

	public void End ()
	{
		System.out.println("Good bye ");
		this.Input = 0;

	}
}